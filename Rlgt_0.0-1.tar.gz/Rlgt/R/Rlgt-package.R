#' @title Getting started with the Rlgt package
#' @name Rlgt-package
#' @aliases Rlgt
#' @docType package
#' @title Getting started with the Rlgt package
# @encoding UTF-8
# @encoding Latin-1
#' @author Slawek Smyl \email{slaweks@@hotmail.co.uk} 
#'
#' Christoph Bergmeir \email{christoph.bergmeir@@gmail.com} 
#' 
#' 
#' @keywords forecasting, exponential smoothing
# @exportPattern "^[[:alpha:]]+"
#' @examples
#' x <- 1
NULL

